package com.alperendemirci.calculator

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.alperendemirci.calculator.databinding.FragmentCalculatorBinding
import java.util.*
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.tan

class CalculatorFragment : Fragment() {
    private lateinit var binding: FragmentCalculatorBinding
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,savedInstanceState: Bundle?): View? {
        binding=FragmentCalculatorBinding.inflate(inflater,container,false)
        // Inflate the layout for this fragment

        var isDegree = true
        lateinit var currOpp:String
        lateinit var helperCurrOpp:String

        binding.switchAngle.setOnCheckedChangeListener { buttonView, isChecked ->
            if(isChecked){
                isDegree=true
                binding.switchAngle.text = "Degrees"
            }
            else{
                isDegree=false
                binding.switchAngle.text = "Radians"
            }
        }

        binding.buttonAdd.setOnClickListener {
            currOpp = binding.buttonAdd.text as String
            helperCurrOpp=binding.buttonAdd.text as String
            binding.textViewOperator.text = "Current Operator : $currOpp"
            binding.textViewFirstNum.text = binding.textNumbers.text
            binding.textNumbers.text=""

        }

        binding.buttonSubstract.setOnClickListener {
            currOpp = binding.buttonSubstract.text as String
            helperCurrOpp=binding.buttonSubstract.text as String
            binding.textViewOperator.text = "Current Operator : $currOpp"
            binding.textViewFirstNum.text = binding.textNumbers.text
            binding.textNumbers.text=""
        }

        binding.buttonMultiply.setOnClickListener {
            currOpp = binding.buttonMultiply.text as String
            helperCurrOpp=binding.buttonMultiply.text as String
            binding.textViewOperator.text = "Current Operator : $currOpp"
            binding.textViewFirstNum.text = binding.textNumbers.text
            binding.textNumbers.text=""
        }

        binding.buttonDivide.setOnClickListener {
            currOpp = binding.buttonDivide.text as String
            helperCurrOpp=binding.buttonDivide.text as String
            binding.textViewOperator.text = "Current Operator : $currOpp"
            binding.textViewFirstNum.text = binding.textNumbers.text
            binding.textNumbers.text=""
        }

        binding.buttonEval.setOnClickListener {
            var result:Double=0.0
            var num1 = binding.textViewFirstNum.text.toString().toDouble()
            var num2:Double

            if(binding.textNumbers.text.toString().equals("")){
                binding.textViewError.text = "ERROR: Please enter a number !"
            }
            else {
                num2= binding.textNumbers.text.toString().toDouble()
                binding.textViewError.text = ""
                when (helperCurrOpp) {
                    "+" -> {
                        result=num1+num2
                        //Change the lastresult thing!!!!!!!
                        binding.textNumbers.text = String.format(Locale.US,"%.4f",result)
                    }
                    "-" -> {
                        result=num1-num2
                        binding.textNumbers.text = String.format(Locale.US,"%.4f",result)
                    }
                    "/" -> {
                        if(num2==0.0){
                            binding.textViewError.text = "ERROR: Can not divide to 0 !"
                        }
                        else{
                            result=num1/num2
                            binding.textNumbers.text = String.format(Locale.US,"%.4f",result)
                        }

                    }
                    "X" -> {
                        result=num1*num2
                        binding.textNumbers.text = String.format(Locale.US,"%.4f",result)
                    }
                }
                binding.textViewFirstNum.text=String.format(Locale.US,"%.4f",result)
            }
        }



        binding.buttonTan.setOnClickListener {
            currOpp = binding.buttonTan.text as String
            binding.textViewOperator.text = "Current Operator : $currOpp"
            var num:Double? = binding.textNumbers.text.toString().toDoubleOrNull()
            if(num==null){
                binding.textViewError.text = "ERROR: Please enter a number !"
            }
            else{
                if(num==90.0 || num==270.0){
                    binding.textViewError.text="ERROR: Can not divide to 0 !"
                }
                else{
                    if(isDegree){
                        Log.e("TAN_FUNC","Num before :$num")
                        num=Math.toRadians(num)
                        Log.e("TAN_FUNC","Num after :$num")
                    }

                    binding.textNumbers.text= String.format(Locale.US,"%.4f",tan(num))
                }
            }



        }

        binding.buttonSin.setOnClickListener {
            currOpp = binding.buttonSin.text as String
            binding.textViewOperator.text = "Current Operator : $currOpp"

            var num:Double? = binding.textNumbers.text.toString().toDoubleOrNull()
            if(num==null){
                binding.textViewError.text = "ERROR: Please enter a number !"
            }
            else {
                if (isDegree) {
                    Log.e("SIN_FUNC", "Num before :$num")
                    num = Math.toRadians(num!!)
                    Log.e("SIN_FUNC", "Num after :$num")
                }
                binding.textNumbers.text = String.format(Locale.US,"%.4f", sin(num!!))
            }
        }


        binding.buttonCos.setOnClickListener {
            currOpp = binding.buttonCos.text as String
            binding.textViewOperator.text = "Current Operator : $currOpp"
            var num:Double? = binding.textNumbers.text.toString().toDoubleOrNull()
            if(num==null){
                binding.textViewError.text = "ERROR: Please enter a number !"
            }
            else {
                if (isDegree) {
                    Log.e("COS_FUNC", "Num before :$num")
                    num = Math.toRadians(num!!)
                    Log.e("COS_FUNC", "Num after :$num")
                }
                binding.textNumbers.text = String.format(Locale.US,"%.4f", cos(num!!))
            }
        }

        binding.buttonCot.setOnClickListener {
            currOpp = binding.buttonCot.text as String
            binding.textViewOperator.text = "Current Operator : $currOpp"

            var num:Double? = binding.textNumbers.text.toString().toDoubleOrNull()
            if(num==null){
                binding.textViewError.text = "ERROR: Please enter a number !"
            }
            else{
                if(num==0.0 || num==180.0){
                    binding.textViewError.text="ERROR: Can not divide to 0 !"
                }
                else{
                    if(isDegree){
                        Log.e("TAN_FUNC","Num before :$num")
                        num=Math.toRadians(num!!)
                        Log.e("TAN_FUNC","Num after :$num")
                    }

                    binding.textNumbers.text= String.format(Locale.US,"%.4f",1/tan(num!!))
                }
            }

        }




        binding.button1.setOnClickListener {
            if(!binding.textNumbers.text.equals("0")) {
                binding.textNumbers.text = "${binding.textNumbers.text}${binding.button1.text}"
            }
            else{
                binding.textNumbers.text = "${binding.button1.text}"
            }
        }
        binding.button2.setOnClickListener {
            if(!binding.textNumbers.text.equals("0")) {
                binding.textNumbers.text = "${binding.textNumbers.text}${binding.button2.text}"
            }
            else{
                binding.textNumbers.text = "${binding.button2.text}"
            }
        }
        binding.button3.setOnClickListener {
            if(!binding.textNumbers.text.equals("0")) {
                binding.textNumbers.text = "${binding.textNumbers.text}${binding.button3.text}"
            }
            else{
                binding.textNumbers.text = "${binding.button3.text}"
            }
        }
        binding.button4.setOnClickListener {
            if(!binding.textNumbers.text.equals("0")) {
                binding.textNumbers.text = "${binding.textNumbers.text}${binding.button4.text}"
            }
            else{
                binding.textNumbers.text = "${binding.button4.text}"
            }
        }
        binding.button5.setOnClickListener {
            if(!binding.textNumbers.text.equals("0")) {
                binding.textNumbers.text = "${binding.textNumbers.text}${binding.button5.text}"
            }
            else{
                binding.textNumbers.text = "${binding.button5.text}"
            }
        }
        binding.button6.setOnClickListener {
            if(!binding.textNumbers.text.equals("0")) {
                binding.textNumbers.text = "${binding.textNumbers.text}${binding.button6.text}"
            }
            else{
                binding.textNumbers.text = "${binding.button6.text}"
            }
        }
        binding.button7.setOnClickListener {
            if(!binding.textNumbers.text.equals("0")) {
                binding.textNumbers.text = "${binding.textNumbers.text}${binding.button7.text}"
            }
            else{
                binding.textNumbers.text = "${binding.button7.text}"
            }
        }

        binding.button8.setOnClickListener {
            if(!binding.textNumbers.text.equals("0")) {
                binding.textNumbers.text = "${binding.textNumbers.text}${binding.button8.text}"
            }
            else{
                binding.textNumbers.text = "${binding.button8.text}"
            }
        }
        binding.button9.setOnClickListener {
            if(!binding.textNumbers.text.equals("0")) {
                binding.textNumbers.text = "${binding.textNumbers.text}${binding.button9.text}"
            }
            else{
                binding.textNumbers.text="${binding.button9.text}\""
            }
        }
        binding.button0.setOnClickListener {
            if(!binding.textNumbers.text.equals("0")) {
                binding.textNumbers.text = "${binding.textNumbers.text}${binding.button0.text}"
            }
            else{
                binding.textNumbers.text = "${binding.button0.text}"
            }
        }
        binding.buttonComma.setOnClickListener {
            if(!binding.textNumbers.text.equals("0")){
                binding.textNumbers.text="${binding.textNumbers.text}${binding.buttonComma.text}"
            }
        }


        binding.buttonClear.setOnClickListener {
            binding.textNumbers.text=""
            currOpp=""
            binding.textViewOperator.text = "Current Operator : $currOpp"
            binding.textViewError.text=""

        }



        return binding.root
    }

}